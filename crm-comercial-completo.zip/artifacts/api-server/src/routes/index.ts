import { Router, type IRouter } from "express";
import healthRouter from "./health.js";
import authRouter from "./auth.js";
import usersRouter from "./users.js";
import clientsRouter from "./clients.js";
import contactsRouter from "./contacts.js";
import salespeopleRouter from "./salespeople.js";
import productsRouter from "./products.js";
import emailsRouter from "./emails.js";
import gmailRouter from "./gmail.js";
import opportunitiesRouter from "./opportunities.js";
import activitiesRouter from "./activities.js";
import dashboardRouter from "./dashboard.js";
import promptsRouter from "./prompts.js";
import importsRouter from "./imports.js";
import extractionsRouter from "./extractions.js";
import followupsRouter from "./followups.js";
import auditRouter from "./audit.js";
import { requireAuth, requireRole, requireMinRole } from "../middleware/auth.js";

const router: IRouter = Router();

router.use(healthRouter);
router.use(authRouter);

router.use(requireAuth);

router.use(dashboardRouter);
router.use(emailsRouter);
router.use(opportunitiesRouter);
router.use(clientsRouter);
router.use(contactsRouter);
router.use(salespeopleRouter);
router.use(productsRouter);
router.use(activitiesRouter);

router.use(gmailRouter);
router.use(importsRouter);
router.use("/extractions", extractionsRouter);
router.use("/followups", requireMinRole("vendedor"), followupsRouter);

router.use("/users", requireRole("admin"), usersRouter);
router.use("/prompts", requireRole("admin", "gerente"), promptsRouter);
router.use("/audit", requireRole("admin", "gerente"), auditRouter);

export default router;
